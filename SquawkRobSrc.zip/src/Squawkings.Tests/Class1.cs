﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Squawkings.Tests
{
    public class Class1
    {
    }
}
