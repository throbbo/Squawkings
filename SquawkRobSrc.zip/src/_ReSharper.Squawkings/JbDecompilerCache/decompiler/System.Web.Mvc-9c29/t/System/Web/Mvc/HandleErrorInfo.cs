﻿// Type: System.Web.Mvc.HandleErrorInfo
// Assembly: System.Web.Mvc, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35
// Assembly location: C:\Program Files\Microsoft ASP.NET\ASP.NET MVC 3\Assemblies\System.Web.Mvc.dll

using System;
using System.Web.Mvc.Resources;

namespace System.Web.Mvc
{
  public class HandleErrorInfo
  {
    public string ActionName { get; private set; }

    public string ControllerName { get; private set; }

    public Exception Exception { get; private set; }

    public HandleErrorInfo(Exception exception, string controllerName, string actionName)
    {
      if (exception == null)
        throw new ArgumentNullException("exception");
      if (string.IsNullOrEmpty(controllerName))
        throw new ArgumentException(MvcResources.Common_NullOrEmpty, "controllerName");
      if (string.IsNullOrEmpty(actionName))
        throw new ArgumentException(MvcResources.Common_NullOrEmpty, "actionName");
      this.Exception = exception;
      this.ControllerName = controllerName;
      this.ActionName = actionName;
    }
  }
}
