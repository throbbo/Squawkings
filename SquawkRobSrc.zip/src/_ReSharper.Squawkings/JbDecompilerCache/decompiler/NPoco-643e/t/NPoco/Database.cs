﻿// Type: NPoco.Database
// Assembly: NPoco, Version=1.0.3.0, Culture=neutral, PublicKeyToken=null
// Assembly location: C:\dev\TrainingTasks\Squawkings\src\packages\NPoco.1.0.3\lib\net40\NPoco.dll

using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Dynamic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;

namespace NPoco
{
  public class Database : IDisposable, IDatabase, IDatabaseQuery
  {
    public static Func<Type, PocoData> PocoDataFactory = (Func<Type, PocoData>) (type => new PocoData(type));
    private string _paramPrefix = "@";
    public const string MsSqlClientProvider = "System.Data.SqlClient";
    private DatabaseType _dbType;
    private string _connectionString;
    private string _providerName;
    private DbProviderFactory _factory;
    private IDbConnection _sharedConnection;
    private IDbTransaction _transaction;
    private int _sharedConnectionDepth;
    private int _transactionDepth;
    private bool _transactionCancelled;
    private string _lastSql;
    private object[] _lastArgs;
    private VersionExceptionHandling _versionException;

    public DatabaseType DatabaseType
    {
      get
      {
        return this._dbType;
      }
    }

    public bool KeepConnectionAlive { get; set; }

    public VersionExceptionHandling VersionException
    {
      get
      {
        return this._versionException;
      }
      set
      {
        this._versionException = value;
      }
    }

    public IDbConnection Connection
    {
      get
      {
        return this._sharedConnection;
      }
    }

    public IDbTransaction Transaction
    {
      get
      {
        return this._transaction;
      }
    }

    public bool ForceDateTimesToUtc { get; set; }

    public bool EnableAutoSelect { get; set; }

    public int CommandTimeout { get; set; }

    public int OneTimeCommandTimeout { get; set; }

    public string LastSQL
    {
      get
      {
        return this._lastSql;
      }
    }

    public object[] LastArgs
    {
      get
      {
        return this._lastArgs;
      }
    }

    public string LastCommand
    {
      get
      {
        return this.FormatCommand(this._lastSql, this._lastArgs);
      }
    }

    public static IMapper Mapper { get; set; }

    static Database()
    {
    }

    public Database(IDbConnection connection)
    {
      this._sharedConnection = connection;
      this._connectionString = connection.ConnectionString;
      this._sharedConnectionDepth = 2;
      this.CommonConstruct();
    }

    public Database(string connectionString, string providerName)
    {
      this._connectionString = connectionString;
      this._providerName = providerName;
      this.CommonConstruct();
    }

    public Database(string connectionString, DbProviderFactory provider)
    {
      this._connectionString = connectionString;
      this._factory = provider;
      this.CommonConstruct();
    }

    public Database(string connectionStringName)
    {
      if (connectionStringName == "")
        connectionStringName = ConfigurationManager.ConnectionStrings[0].Name;
      string str = "System.Data.SqlClient";
      if (ConfigurationManager.ConnectionStrings[connectionStringName] == null)
        throw new InvalidOperationException("Can't find a connection string with the name '" + connectionStringName + "'");
      if (!string.IsNullOrEmpty(ConfigurationManager.ConnectionStrings[connectionStringName].ProviderName))
        str = ConfigurationManager.ConnectionStrings[connectionStringName].ProviderName;
      this._connectionString = ConfigurationManager.ConnectionStrings[connectionStringName].ConnectionString;
      this._providerName = str;
      this.CommonConstruct();
    }

    private void CommonConstruct()
    {
      this._transactionDepth = 0;
      this.ForceDateTimesToUtc = true;
      this.EnableAutoSelect = true;
      if (this._providerName != null)
        this._factory = DbProviderFactories.GetFactory(this._providerName);
      this._dbType = DatabaseType.Resolve((this._factory == null ? (MemberInfo) this._sharedConnection.GetType() : (MemberInfo) this._factory.GetType()).Name, this._providerName);
      this._paramPrefix = this._dbType.GetParameterPrefix(this._connectionString);
    }

    public void Dispose()
    {
      this.CloseSharedConnection();
    }

    public void OpenSharedConnection()
    {
      if (this._sharedConnectionDepth == 0)
      {
        this._sharedConnection = (IDbConnection) this._factory.CreateConnection();
        this._sharedConnection.ConnectionString = this._connectionString;
        if (this._sharedConnection.State == ConnectionState.Broken)
          this._sharedConnection.Close();
        if (this._sharedConnection.State == ConnectionState.Closed)
          this._sharedConnection.Open();
        this._sharedConnection = this.OnConnectionOpened(this._sharedConnection);
        if (this.KeepConnectionAlive)
          ++this._sharedConnectionDepth;
      }
      ++this._sharedConnectionDepth;
    }

    public void CloseSharedConnection()
    {
      if (this._sharedConnectionDepth <= 0)
        return;
      --this._sharedConnectionDepth;
      if (this._sharedConnectionDepth != 0)
        return;
      this.OnConnectionClosing(this._sharedConnection);
      this._sharedConnection.Dispose();
      this._sharedConnection = (IDbConnection) null;
    }

    public IDataParameter CreateParameter()
    {
      using (IDbConnection dbConnection = this._sharedConnection ?? (IDbConnection) this._factory.CreateConnection())
      {
        using (IDbCommand command = dbConnection.CreateCommand())
          return (IDataParameter) command.CreateParameter();
      }
    }

    public Transaction GetTransaction()
    {
      return this.GetTransaction(new IsolationLevel?());
    }

    public Transaction GetTransaction(IsolationLevel? isolationLevel)
    {
      return new Transaction(this, isolationLevel);
    }

    public IDatabase SetTransaction(IDbTransaction tran)
    {
      this._transaction = tran;
      ++this._transactionDepth;
      return (IDatabase) this;
    }

    public virtual void OnBeginTransaction()
    {
    }

    public virtual void OnEndTransaction()
    {
    }

    public void BeginTransaction()
    {
      this.BeginTransaction(new IsolationLevel?());
    }

    public void BeginTransaction(IsolationLevel? isolationLevel)
    {
      ++this._transactionDepth;
      if (this._transactionDepth != 1)
        return;
      this.OpenSharedConnection();
      this._transaction = !isolationLevel.HasValue ? this._sharedConnection.BeginTransaction() : this._sharedConnection.BeginTransaction(isolationLevel.Value);
      this._transactionCancelled = false;
      this.OnBeginTransaction();
    }

    private void CleanupTransaction()
    {
      this.OnEndTransaction();
      if (this._transactionCancelled)
        this._transaction.Rollback();
      else
        this._transaction.Commit();
      this._transaction.Dispose();
      this._transaction = (IDbTransaction) null;
      this.CloseSharedConnection();
    }

    public void AbortTransaction()
    {
      this._transactionCancelled = true;
      if (--this._transactionDepth != 0)
        return;
      this.CleanupTransaction();
    }

    public void CompleteTransaction()
    {
      if (--this._transactionDepth != 0)
        return;
      this.CleanupTransaction();
    }

    private void AddParam(IDbCommand cmd, object value, string ParameterPrefix)
    {
      if (Database.Mapper != null && value != null)
      {
        Func<object, object> parameterConverter = Database.Mapper.GetParameterConverter(value.GetType());
        if (parameterConverter != null)
          value = parameterConverter(value);
      }
      IDbDataParameter dbDataParameter = value as IDbDataParameter;
      if (dbDataParameter != null)
      {
        dbDataParameter.ParameterName = string.Format("{0}{1}", (object) ParameterPrefix, (object) cmd.Parameters.Count);
        cmd.Parameters.Add((object) dbDataParameter);
      }
      else
      {
        IDbDataParameter parameter = cmd.CreateParameter();
        parameter.ParameterName = string.Format("{0}{1}", (object) ParameterPrefix, (object) cmd.Parameters.Count);
        if (value == null)
        {
          parameter.Value = (object) DBNull.Value;
        }
        else
        {
          value = this._dbType.MapParameterValue(value);
          Type type = value.GetType();
          if (type.IsEnum)
            parameter.Value = (object) (int) value;
          else if (type == typeof (Guid))
          {
            parameter.Value = (object) value.ToString();
            parameter.DbType = DbType.String;
            parameter.Size = 40;
          }
          else if (type == typeof (string))
          {
            if ((value as string).Length + 1 > 4000 && parameter.GetType().Name == "SqlCeParameter")
              parameter.GetType().GetProperty("SqlDbType").SetValue((object) parameter, (object) SqlDbType.NText, (object[]) null);
            parameter.Size = Math.Max((value as string).Length + 1, 4000);
            parameter.Value = value;
          }
          else if (type == typeof (AnsiString))
          {
            parameter.Size = Math.Max((value as AnsiString).Value.Length + 1, 4000);
            parameter.Value = (object) (value as AnsiString).Value;
            parameter.DbType = DbType.AnsiString;
          }
          else if (value.GetType().Name == "SqlGeography")
          {
            parameter.GetType().GetProperty("UdtTypeName").SetValue((object) parameter, (object) "geography", (object[]) null);
            parameter.Value = value;
          }
          else if (value.GetType().Name == "SqlGeometry")
          {
            parameter.GetType().GetProperty("UdtTypeName").SetValue((object) parameter, (object) "geometry", (object[]) null);
            parameter.Value = value;
          }
          else
            parameter.Value = value;
        }
        cmd.Parameters.Add((object) parameter);
      }
    }

    private IDbCommand CreateCommand(IDbConnection connection, string sql, params object[] args)
    {
      if (this._paramPrefix != "@")
        sql = ParameterHelper.rxParamsPrefix.Replace(sql, (MatchEvaluator) (m => this._paramPrefix + m.Value.Substring(1)));
      sql = sql.Replace("@@", "@");
      IDbCommand command = connection.CreateCommand();
      command.Connection = connection;
      command.CommandText = sql;
      command.Transaction = this._transaction;
      foreach (object obj in args)
        this.AddParam(command, obj, this._paramPrefix);
      this._dbType.PreExecute(command);
      if (!string.IsNullOrEmpty(sql))
        this.DoPreExecute(command);
      return command;
    }

    public virtual void OnException(Exception x)
    {
    }

    public virtual IDbConnection OnConnectionOpened(IDbConnection conn)
    {
      return conn;
    }

    public virtual void OnConnectionClosing(IDbConnection conn)
    {
    }

    public virtual void OnExecutingCommand(IDbCommand cmd)
    {
    }

    public virtual void OnExecutedCommand(IDbCommand cmd)
    {
    }

    public int Execute(string sql, params object[] args)
    {
      return this.Execute(new Sql(sql, args));
    }

    public int Execute(Sql Sql)
    {
      string sql = Sql.SQL;
      object[] arguments = Sql.Arguments;
      try
      {
        this.OpenSharedConnection();
        try
        {
          using (IDbCommand command = this.CreateCommand(this._sharedConnection, sql, arguments))
          {
            int num = command.ExecuteNonQuery();
            this.OnExecutedCommand(command);
            return num;
          }
        }
        finally
        {
          this.CloseSharedConnection();
        }
      }
      catch (Exception ex)
      {
        this.OnException(ex);
        throw;
      }
    }

    public T ExecuteScalar<T>(string sql, params object[] args)
    {
      return this.ExecuteScalar<T>(new Sql(sql, args));
    }

    public T ExecuteScalar<T>(Sql Sql)
    {
      string sql = Sql.SQL;
      object[] arguments = Sql.Arguments;
      try
      {
        this.OpenSharedConnection();
        try
        {
          using (IDbCommand command = this.CreateCommand(this._sharedConnection, sql, arguments))
          {
            object obj = command.ExecuteScalar();
            this.OnExecutedCommand(command);
            if (obj == null || obj == DBNull.Value)
              return default (T);
            Type nullableType = typeof (T);
            Type underlyingType = Nullable.GetUnderlyingType(nullableType);
            return (T) Convert.ChangeType(obj, underlyingType ?? nullableType);
          }
        }
        finally
        {
          this.CloseSharedConnection();
        }
      }
      catch (Exception ex)
      {
        this.OnException(ex);
        throw;
      }
    }

    public List<T> Fetch<T>(string sql, params object[] args)
    {
      return this.Fetch<T>(new Sql(sql, args));
    }

    public List<T> Fetch<T>(Sql sql)
    {
      return Enumerable.ToList<T>(this.Query<T>(sql));
    }

    public List<T> Fetch<T>()
    {
      return this.Fetch<T>("", new object[0]);
    }

    public void BuildPageQueries<T>(long skip, long take, string sql, ref object[] args, out string sqlCount, out string sqlPage)
    {
      if (this.EnableAutoSelect)
        sql = AutoSelectHelper.AddSelectClause<T>(this._dbType, sql);
      PagingHelper.SQLParts parts;
      if (!PagingHelper.SplitSQL(sql, out parts))
        throw new Exception("Unable to parse SQL statement for paged query");
      sqlPage = this._dbType.BuildPageQuery(skip, take, parts, ref args);
      sqlCount = parts.sqlCount;
    }

    public Page<T> Page<T>(long page, long itemsPerPage, string sql, params object[] args)
    {
      string sqlCount;
      string sqlPage;
      this.BuildPageQueries<T>((page - 1L) * itemsPerPage, itemsPerPage, sql, ref args, out sqlCount, out sqlPage);
      int timeCommandTimeout = this.OneTimeCommandTimeout;
      Page<T> page1 = new Page<T>();
      page1.CurrentPage = page;
      page1.ItemsPerPage = itemsPerPage;
      page1.TotalItems = this.ExecuteScalar<long>(sqlCount, args);
      page1.TotalPages = page1.TotalItems / itemsPerPage;
      if (page1.TotalItems % itemsPerPage != 0L)
        ++page1.TotalPages;
      this.OneTimeCommandTimeout = timeCommandTimeout;
      page1.Items = this.Fetch<T>(sqlPage, args);
      return page1;
    }

    public Page<T> Page<T>(long page, long itemsPerPage, Sql sql)
    {
      return this.Page<T>(page, itemsPerPage, sql.SQL, sql.Arguments);
    }

    public List<T> Fetch<T>(long page, long itemsPerPage, string sql, params object[] args)
    {
      return this.SkipTake<T>((page - 1L) * itemsPerPage, itemsPerPage, sql, args);
    }

    public List<T> Fetch<T>(long page, long itemsPerPage, Sql sql)
    {
      return this.SkipTake<T>((page - 1L) * itemsPerPage, itemsPerPage, sql.SQL, sql.Arguments);
    }

    public List<T> SkipTake<T>(long skip, long take, string sql, params object[] args)
    {
      string sqlCount;
      string sqlPage;
      this.BuildPageQueries<T>(skip, take, sql, ref args, out sqlCount, out sqlPage);
      return this.Fetch<T>(sqlPage, args);
    }

    public List<T> SkipTake<T>(long skip, long take, Sql sql)
    {
      return this.SkipTake<T>(skip, take, sql.SQL, sql.Arguments);
    }

    public Dictionary<TKey, TValue> Dictionary<TKey, TValue>(Sql Sql)
    {
      return this.Dictionary<TKey, TValue>(Sql.SQL, Sql.Arguments);
    }

    public Dictionary<TKey, TValue> Dictionary<TKey, TValue>(string sql, params object[] args)
    {
      Dictionary<TKey, TValue> dictionary1 = new Dictionary<TKey, TValue>();
      bool flag = false;
      Func<object, object> func1 = (Func<object, object>) (x => x);
      Func<object, object> func2 = (Func<object, object>) (x => x);
      foreach (Dictionary<string, object> dictionary2 in this.Query<Dictionary<string, object>>(sql, args))
      {
        object obj1 = Enumerable.ElementAt<KeyValuePair<string, object>>((IEnumerable<KeyValuePair<string, object>>) dictionary2, 0).Value;
        object obj2 = Enumerable.ElementAt<KeyValuePair<string, object>>((IEnumerable<KeyValuePair<string, object>>) dictionary2, 1).Value;
        if (!flag)
        {
          func1 = PocoData.GetConverter((PocoColumn) null, typeof (TKey), obj1.GetType()) ?? (Func<object, object>) (x => x);
          func2 = PocoData.GetConverter((PocoColumn) null, typeof (TValue), obj2.GetType()) ?? (Func<object, object>) (x => x);
          flag = true;
        }
        TKey key = (TKey) Convert.ChangeType(func1(obj1), typeof (TKey));
        Type conversionType = Nullable.GetUnderlyingType(typeof (TValue)) ?? typeof (TValue);
        object obj3 = func2(obj2);
        TValue obj4 = obj3 != null ? (TValue) Convert.ChangeType(obj3, conversionType) : default (TValue);
        if ((object) key != null)
          dictionary1.Add(key, obj4);
      }
      return dictionary1;
    }

    public IEnumerable<T> Query<T>(string sql, params object[] args)
    {
      return this.Query<T>(new Sql(sql, args));
    }

    public IEnumerable<T> Query<T>(Sql Sql)
    {
      return this.Query<T>(default (T), Sql);
    }

    private IEnumerable<T> Query<T>(T instance, Sql Sql)
    {
      string sql = Sql.SQL;
      object[] args = Sql.Arguments;
      if (this.EnableAutoSelect)
        sql = AutoSelectHelper.AddSelectClause<T>(this._dbType, sql);
      this.OpenSharedConnection();
      try
      {
        using (IDbCommand command = this.CreateCommand(this._sharedConnection, sql, args))
        {
          PocoData pd = PocoData.ForType(typeof (T));
          IDataReader r;
          try
          {
            r = command.ExecuteReader();
            this.OnExecutedCommand(command);
          }
          catch (Exception ex)
          {
            this.OnException(ex);
            throw;
          }
          using (r)
          {
            Func<IDataReader, T, T> factory = pd.GetFactory(command.CommandText, this._sharedConnection.ConnectionString, 0, r.FieldCount, r, (object) (T) instance) as Func<IDataReader, T, T>;
label_8:
            T poco;
            try
            {
              if (!r.Read())
              {
                // ISSUE: reference to a compiler-generated method
                this.System\u002EIDisposable\u002EDispose();
                yield break;
              }
              else
                poco = factory(r, instance);
            }
            catch (Exception ex)
            {
              this.OnException(ex);
              throw;
            }
            yield return poco;
            goto label_8;
          }
        }
      }
      finally
      {
        this.CloseSharedConnection();
      }
    }

    public List<TRet> Fetch<T1, T2, TRet>(Func<T1, T2, TRet> cb, string sql, params object[] args)
    {
      return Enumerable.ToList<TRet>(this.Query<T1, T2, TRet>(cb, sql, args));
    }

    public List<TRet> Fetch<T1, T2, T3, TRet>(Func<T1, T2, T3, TRet> cb, string sql, params object[] args)
    {
      return Enumerable.ToList<TRet>(this.Query<T1, T2, T3, TRet>(cb, sql, args));
    }

    public List<TRet> Fetch<T1, T2, T3, T4, TRet>(Func<T1, T2, T3, T4, TRet> cb, string sql, params object[] args)
    {
      return Enumerable.ToList<TRet>(this.Query<T1, T2, T3, T4, TRet>(cb, sql, args));
    }

    public IEnumerable<TRet> Query<T1, T2, TRet>(Func<T1, T2, TRet> cb, string sql, params object[] args)
    {
      return this.Query<TRet>(new Type[2]
      {
        typeof (T1),
        typeof (T2)
      }, (object) cb, new Sql(sql, args));
    }

    public IEnumerable<TRet> Query<T1, T2, T3, TRet>(Func<T1, T2, T3, TRet> cb, string sql, params object[] args)
    {
      return this.Query<TRet>(new Type[3]
      {
        typeof (T1),
        typeof (T2),
        typeof (T3)
      }, (object) cb, new Sql(sql, args));
    }

    public IEnumerable<TRet> Query<T1, T2, T3, T4, TRet>(Func<T1, T2, T3, T4, TRet> cb, string sql, params object[] args)
    {
      return this.Query<TRet>(new Type[4]
      {
        typeof (T1),
        typeof (T2),
        typeof (T3),
        typeof (T4)
      }, (object) cb, new Sql(sql, args));
    }

    public List<TRet> Fetch<T1, T2, TRet>(Func<T1, T2, TRet> cb, Sql sql)
    {
      return Enumerable.ToList<TRet>(this.Query<T1, T2, TRet>(cb, sql));
    }

    public List<TRet> Fetch<T1, T2, T3, TRet>(Func<T1, T2, T3, TRet> cb, Sql sql)
    {
      return Enumerable.ToList<TRet>(this.Query<T1, T2, T3, TRet>(cb, sql));
    }

    public List<TRet> Fetch<T1, T2, T3, T4, TRet>(Func<T1, T2, T3, T4, TRet> cb, Sql sql)
    {
      return Enumerable.ToList<TRet>(this.Query<T1, T2, T3, T4, TRet>(cb, sql));
    }

    public IEnumerable<TRet> Query<T1, T2, TRet>(Func<T1, T2, TRet> cb, Sql sql)
    {
      return this.Query<TRet>(new Type[2]
      {
        typeof (T1),
        typeof (T2)
      }, (object) cb, sql);
    }

    public IEnumerable<TRet> Query<T1, T2, T3, TRet>(Func<T1, T2, T3, TRet> cb, Sql sql)
    {
      return this.Query<TRet>(new Type[3]
      {
        typeof (T1),
        typeof (T2),
        typeof (T3)
      }, (object) cb, sql);
    }

    public IEnumerable<TRet> Query<T1, T2, T3, T4, TRet>(Func<T1, T2, T3, T4, TRet> cb, Sql sql)
    {
      return this.Query<TRet>(new Type[4]
      {
        typeof (T1),
        typeof (T2),
        typeof (T3),
        typeof (T4)
      }, (object) cb, sql);
    }

    public List<T1> Fetch<T1, T2>(string sql, params object[] args)
    {
      return Enumerable.ToList<T1>(this.Query<T1, T2>(sql, args));
    }

    public List<T1> Fetch<T1, T2, T3>(string sql, params object[] args)
    {
      return Enumerable.ToList<T1>(this.Query<T1, T2, T3>(sql, args));
    }

    public List<T1> Fetch<T1, T2, T3, T4>(string sql, params object[] args)
    {
      return Enumerable.ToList<T1>(this.Query<T1, T2, T3, T4>(sql, args));
    }

    public IEnumerable<T1> Query<T1, T2>(string sql, params object[] args)
    {
      return this.Query<T1>(new Type[2]
      {
        typeof (T1),
        typeof (T2)
      }, (object) null, new Sql(sql, args));
    }

    public IEnumerable<T1> Query<T1, T2, T3>(string sql, params object[] args)
    {
      return this.Query<T1>(new Type[3]
      {
        typeof (T1),
        typeof (T2),
        typeof (T3)
      }, (object) null, new Sql(sql, args));
    }

    public IEnumerable<T1> Query<T1, T2, T3, T4>(string sql, params object[] args)
    {
      return this.Query<T1>(new Type[4]
      {
        typeof (T1),
        typeof (T2),
        typeof (T3),
        typeof (T4)
      }, (object) null, new Sql(sql, args));
    }

    public List<T1> Fetch<T1, T2>(Sql sql)
    {
      return Enumerable.ToList<T1>(this.Query<T1, T2>(sql));
    }

    public List<T1> Fetch<T1, T2, T3>(Sql sql)
    {
      return Enumerable.ToList<T1>(this.Query<T1, T2, T3>(sql));
    }

    public List<T1> Fetch<T1, T2, T3, T4>(Sql sql)
    {
      return Enumerable.ToList<T1>(this.Query<T1, T2, T3, T4>(sql));
    }

    public IEnumerable<T1> Query<T1, T2>(Sql sql)
    {
      return this.Query<T1>(new Type[2]
      {
        typeof (T1),
        typeof (T2)
      }, (object) null, sql);
    }

    public IEnumerable<T1> Query<T1, T2, T3>(Sql sql)
    {
      return this.Query<T1>(new Type[3]
      {
        typeof (T1),
        typeof (T2),
        typeof (T3)
      }, (object) null, sql);
    }

    public IEnumerable<T1> Query<T1, T2, T3, T4>(Sql sql)
    {
      return this.Query<T1>(new Type[4]
      {
        typeof (T1),
        typeof (T2),
        typeof (T3),
        typeof (T4)
      }, (object) null, sql);
    }

    public IEnumerable<TRet> Query<TRet>(Type[] types, object cb, Sql sql)
    {
      this.OpenSharedConnection();
      try
      {
        using (IDbCommand command = this.CreateCommand(this._sharedConnection, sql.SQL, sql.Arguments))
        {
          IDataReader r;
          try
          {
            r = command.ExecuteReader();
            this.OnExecutedCommand(command);
          }
          catch (Exception ex)
          {
            this.OnException(ex);
            throw;
          }
          Func<IDataReader, object, TRet> factory = MultiPocoFactory.GetMultiPocoFactory<TRet>(types, sql.SQL, this._sharedConnection.ConnectionString, r);
          if (cb == null)
            cb = MultiPocoFactory.GetAutoMapper(Enumerable.ToArray<Type>((IEnumerable<Type>) types));
          bool bNeedTerminator = false;
          using (r)
          {
label_6:
            TRet poco1;
            try
            {
              if (r.Read())
                poco1 = factory(r, cb);
              else
                goto label_12;
            }
            catch (Exception ex)
            {
              this.OnException(ex);
              throw;
            }
            if ((object) poco1 != null)
            {
              yield return poco1;
              goto label_6;
            }
            else
            {
              bNeedTerminator = true;
              goto label_6;
            }
label_12:
            if (bNeedTerminator)
            {
              TRet poco2 = (TRet) (cb as Delegate).DynamicInvoke(new object[types.Length]);
              if ((object) poco2 != null)
              {
                yield return poco2;
              }
              else
              {
                // ISSUE: reference to a compiler-generated method
                this.System\u002EIDisposable\u002EDispose();
              }
            }
          }
        }
      }
      finally
      {
        this.CloseSharedConnection();
      }
    }

    public TRet FetchMultiple<T1, T2, TRet>(Func<List<T1>, List<T2>, TRet> cb, string sql, params object[] args)
    {
      return this.FetchMultiple<T1, T2, Database.DontMap, Database.DontMap, TRet>(new Type[2]
      {
        typeof (T1),
        typeof (T2)
      }, (object) cb, new Sql(sql, args));
    }

    public TRet FetchMultiple<T1, T2, T3, TRet>(Func<List<T1>, List<T2>, List<T3>, TRet> cb, string sql, params object[] args)
    {
      return this.FetchMultiple<T1, T2, T3, Database.DontMap, TRet>(new Type[3]
      {
        typeof (T1),
        typeof (T2),
        typeof (T3)
      }, (object) cb, new Sql(sql, args));
    }

    public TRet FetchMultiple<T1, T2, T3, T4, TRet>(Func<List<T1>, List<T2>, List<T3>, List<T4>, TRet> cb, string sql, params object[] args)
    {
      return this.FetchMultiple<T1, T2, T3, T4, TRet>(new Type[4]
      {
        typeof (T1),
        typeof (T2),
        typeof (T3),
        typeof (T4)
      }, (object) cb, new Sql(sql, args));
    }

    public TRet FetchMultiple<T1, T2, TRet>(Func<List<T1>, List<T2>, TRet> cb, Sql sql)
    {
      return this.FetchMultiple<T1, T2, Database.DontMap, Database.DontMap, TRet>(new Type[2]
      {
        typeof (T1),
        typeof (T2)
      }, (object) cb, sql);
    }

    public TRet FetchMultiple<T1, T2, T3, TRet>(Func<List<T1>, List<T2>, List<T3>, TRet> cb, Sql sql)
    {
      return this.FetchMultiple<T1, T2, T3, Database.DontMap, TRet>(new Type[3]
      {
        typeof (T1),
        typeof (T2),
        typeof (T3)
      }, (object) cb, sql);
    }

    public TRet FetchMultiple<T1, T2, T3, T4, TRet>(Func<List<T1>, List<T2>, List<T3>, List<T4>, TRet> cb, Sql sql)
    {
      return this.FetchMultiple<T1, T2, T3, T4, TRet>(new Type[4]
      {
        typeof (T1),
        typeof (T2),
        typeof (T3),
        typeof (T4)
      }, (object) cb, sql);
    }

    public Tuple<List<T1>, List<T2>> FetchMultiple<T1, T2>(string sql, params object[] args)
    {
      return this.FetchMultiple<T1, T2, Database.DontMap, Database.DontMap, Tuple<List<T1>, List<T2>>>(new Type[2]
      {
        typeof (T1),
        typeof (T2)
      }, (object) (Func<List<T1>, List<T2>, Tuple<List<T1>, List<T2>>>) ((y, z) => new Tuple<List<T1>, List<T2>>(y, z)), new Sql(sql, args));
    }

    public Tuple<List<T1>, List<T2>, List<T3>> FetchMultiple<T1, T2, T3>(string sql, params object[] args)
    {
      return this.FetchMultiple<T1, T2, T3, Database.DontMap, Tuple<List<T1>, List<T2>, List<T3>>>(new Type[3]
      {
        typeof (T1),
        typeof (T2),
        typeof (T3)
      }, (object) (Func<List<T1>, List<T2>, List<T3>, Tuple<List<T1>, List<T2>, List<T3>>>) ((x, y, z) => new Tuple<List<T1>, List<T2>, List<T3>>(x, y, z)), new Sql(sql, args));
    }

    public Tuple<List<T1>, List<T2>, List<T3>, List<T4>> FetchMultiple<T1, T2, T3, T4>(string sql, params object[] args)
    {
      return this.FetchMultiple<T1, T2, T3, T4, Tuple<List<T1>, List<T2>, List<T3>, List<T4>>>(new Type[4]
      {
        typeof (T1),
        typeof (T2),
        typeof (T3),
        typeof (T4)
      }, (object) (Func<List<T1>, List<T2>, List<T3>, List<T4>, Tuple<List<T1>, List<T2>, List<T3>, List<T4>>>) ((w, x, y, z) => new Tuple<List<T1>, List<T2>, List<T3>, List<T4>>(w, x, y, z)), new Sql(sql, args));
    }

    public Tuple<List<T1>, List<T2>> FetchMultiple<T1, T2>(Sql sql)
    {
      return this.FetchMultiple<T1, T2, Database.DontMap, Database.DontMap, Tuple<List<T1>, List<T2>>>(new Type[2]
      {
        typeof (T1),
        typeof (T2)
      }, (object) (Func<List<T1>, List<T2>, Tuple<List<T1>, List<T2>>>) ((y, z) => new Tuple<List<T1>, List<T2>>(y, z)), sql);
    }

    public Tuple<List<T1>, List<T2>, List<T3>> FetchMultiple<T1, T2, T3>(Sql sql)
    {
      return this.FetchMultiple<T1, T2, T3, Database.DontMap, Tuple<List<T1>, List<T2>, List<T3>>>(new Type[3]
      {
        typeof (T1),
        typeof (T2),
        typeof (T3)
      }, (object) (Func<List<T1>, List<T2>, List<T3>, Tuple<List<T1>, List<T2>, List<T3>>>) ((x, y, z) => new Tuple<List<T1>, List<T2>, List<T3>>(x, y, z)), sql);
    }

    public Tuple<List<T1>, List<T2>, List<T3>, List<T4>> FetchMultiple<T1, T2, T3, T4>(Sql sql)
    {
      return this.FetchMultiple<T1, T2, T3, T4, Tuple<List<T1>, List<T2>, List<T3>, List<T4>>>(new Type[4]
      {
        typeof (T1),
        typeof (T2),
        typeof (T3),
        typeof (T4)
      }, (object) (Func<List<T1>, List<T2>, List<T3>, List<T4>, Tuple<List<T1>, List<T2>, List<T3>, List<T4>>>) ((w, x, y, z) => new Tuple<List<T1>, List<T2>, List<T3>, List<T4>>(w, x, y, z)), sql);
    }

    private TRet FetchMultiple<T1, T2, T3, T4, TRet>(Type[] types, object cb, Sql Sql)
    {
      string sql = Sql.SQL;
      object[] arguments = Sql.Arguments;
      this.OpenSharedConnection();
      try
      {
        using (IDbCommand command = this.CreateCommand(this._sharedConnection, sql, arguments))
        {
          IDataReader r;
          try
          {
            r = command.ExecuteReader();
            this.OnExecutedCommand(command);
          }
          catch (Exception ex)
          {
            this.OnException(ex);
            throw;
          }
          using (r)
          {
            int num = 1;
            List<T1> list1 = new List<T1>();
            List<T2> list2 = new List<T2>();
            List<T3> list3 = new List<T3>();
            List<T4> list4 = new List<T4>();
            while (num <= types.Length)
            {
              Delegate factory = PocoData.ForType(types[num - 1]).GetFactory(command.CommandText, this._sharedConnection.ConnectionString, 0, r.FieldCount, r, (object) null);
              while (true)
              {
                try
                {
                  if (r.Read())
                  {
                    switch (num)
                    {
                      case 1:
                        list1.Add(((Func<IDataReader, T1, T1>) factory)(r, default (T1)));
                        continue;
                      case 2:
                        list2.Add(((Func<IDataReader, T2, T2>) factory)(r, default (T2)));
                        continue;
                      case 3:
                        list3.Add(((Func<IDataReader, T3, T3>) factory)(r, default (T3)));
                        continue;
                      case 4:
                        list4.Add(((Func<IDataReader, T4, T4>) factory)(r, default (T4)));
                        continue;
                      default:
                        continue;
                    }
                  }
                  else
                    break;
                }
                catch (Exception ex)
                {
                  this.OnException(ex);
                  throw;
                }
              }
              ++num;
              if (!r.NextResult())
                break;
            }
            switch (types.Length)
            {
              case 2:
                return ((Func<List<T1>, List<T2>, TRet>) cb)(list1, list2);
              case 3:
                return ((Func<List<T1>, List<T2>, List<T3>, TRet>) cb)(list1, list2, list3);
              case 4:
                return ((Func<List<T1>, List<T2>, List<T3>, List<T4>, TRet>) cb)(list1, list2, list3, list4);
              default:
                return default (TRet);
            }
          }
        }
      }
      finally
      {
        this.CloseSharedConnection();
      }
    }

    public bool Exists<T>(object primaryKey)
    {
      int index = 0;
      Dictionary<string, object> primaryKeyValues = this.GetPrimaryKeyValues(PocoData.ForType(typeof (T)).TableInfo.PrimaryKey, primaryKey);
      return (object) this.FirstOrDefault<T>(string.Format("WHERE {0}", (object) this.BuildPrimaryKeySql(primaryKeyValues, ref index)), Enumerable.ToArray<object>(Enumerable.Select<KeyValuePair<string, object>, object>((IEnumerable<KeyValuePair<string, object>>) primaryKeyValues, (Func<KeyValuePair<string, object>, object>) (x => x.Value)))) != null;
    }

    public T SingleById<T>(object primaryKey)
    {
      int index = 0;
      Dictionary<string, object> primaryKeyValues = this.GetPrimaryKeyValues(PocoData.ForType(typeof (T)).TableInfo.PrimaryKey, primaryKey);
      return this.Single<T>(string.Format("WHERE {0}", (object) this.BuildPrimaryKeySql(primaryKeyValues, ref index)), Enumerable.ToArray<object>(Enumerable.Select<KeyValuePair<string, object>, object>((IEnumerable<KeyValuePair<string, object>>) primaryKeyValues, (Func<KeyValuePair<string, object>, object>) (x => x.Value))));
    }

    public T SingleOrDefaultById<T>(object primaryKey)
    {
      int index = 0;
      Dictionary<string, object> primaryKeyValues = this.GetPrimaryKeyValues(PocoData.ForType(typeof (T)).TableInfo.PrimaryKey, primaryKey);
      return this.SingleOrDefault<T>(string.Format("WHERE {0}", (object) this.BuildPrimaryKeySql(primaryKeyValues, ref index)), Enumerable.ToArray<object>(Enumerable.Select<KeyValuePair<string, object>, object>((IEnumerable<KeyValuePair<string, object>>) primaryKeyValues, (Func<KeyValuePair<string, object>, object>) (x => x.Value))));
    }

    public T Single<T>(string sql, params object[] args)
    {
      return Enumerable.Single<T>(this.Query<T>(sql, args));
    }

    public T SingleInto<T>(T instance, string sql, params object[] args)
    {
      return Enumerable.Single<T>(this.Query<T>(instance, new Sql(sql, args)));
    }

    public T SingleOrDefault<T>(string sql, params object[] args)
    {
      return Enumerable.SingleOrDefault<T>(this.Query<T>(sql, args));
    }

    public T SingleOrDefaultInto<T>(T instance, string sql, params object[] args)
    {
      return Enumerable.SingleOrDefault<T>(this.Query<T>(instance, new Sql(sql, args)));
    }

    public T First<T>(string sql, params object[] args)
    {
      return Enumerable.First<T>(this.Query<T>(sql, args));
    }

    public T FirstInto<T>(T instance, string sql, params object[] args)
    {
      return Enumerable.First<T>(this.Query<T>(instance, new Sql(sql, args)));
    }

    public T FirstOrDefault<T>(string sql, params object[] args)
    {
      return Enumerable.FirstOrDefault<T>(this.Query<T>(sql, args));
    }

    public T FirstOrDefaultInto<T>(T instance, string sql, params object[] args)
    {
      return Enumerable.FirstOrDefault<T>(this.Query<T>(instance, new Sql(sql, args)));
    }

    public T Single<T>(Sql sql)
    {
      return Enumerable.Single<T>(this.Query<T>(sql));
    }

    public T SingleInto<T>(T instance, Sql sql)
    {
      return Enumerable.Single<T>(this.Query<T>(instance, sql));
    }

    public T SingleOrDefault<T>(Sql sql)
    {
      return Enumerable.SingleOrDefault<T>(this.Query<T>(sql));
    }

    public T SingleOrDefaultInto<T>(T instance, Sql sql)
    {
      return Enumerable.SingleOrDefault<T>(this.Query<T>(instance, sql));
    }

    public T First<T>(Sql sql)
    {
      return Enumerable.First<T>(this.Query<T>(sql));
    }

    public T FirstInto<T>(T instance, Sql sql)
    {
      return Enumerable.First<T>(this.Query<T>(instance, sql));
    }

    public T FirstOrDefault<T>(Sql sql)
    {
      return Enumerable.FirstOrDefault<T>(this.Query<T>(sql));
    }

    public T FirstOrDefaultInto<T>(T instance, Sql sql)
    {
      return Enumerable.FirstOrDefault<T>(this.Query<T>(instance, sql));
    }

    public object Insert(string tableName, string primaryKeyName, object poco)
    {
      return this.Insert(tableName, primaryKeyName, true, poco);
    }

    public object Insert(string tableName, string primaryKeyName, bool autoIncrement, object poco)
    {
      try
      {
        this.OpenSharedConnection();
        try
        {
          PocoData pocoData = PocoData.ForObject(poco, primaryKeyName);
          List<string> list1 = new List<string>();
          List<string> list2 = new List<string>();
          List<object> list3 = new List<object>();
          int num = 0;
          string key = "";
          foreach (KeyValuePair<string, PocoColumn> keyValuePair in pocoData.Columns)
          {
            if (!keyValuePair.Value.ResultColumn)
            {
              if (autoIncrement && primaryKeyName != null && string.Compare(keyValuePair.Key, primaryKeyName, true) == 0)
              {
                string incrementExpression = this._dbType.GetAutoIncrementExpression(pocoData.TableInfo);
                if (incrementExpression != null)
                {
                  list1.Add(keyValuePair.Key);
                  list2.Add(incrementExpression);
                }
              }
              else
              {
                list1.Add(this._dbType.EscapeSqlIdentifier(keyValuePair.Key));
                list2.Add(string.Format("{0}{1}", (object) this._paramPrefix, (object) num++));
                object obj = keyValuePair.Value.GetValue(poco);
                if (Database.Mapper != null)
                {
                  Func<object, object> toDbConverter = Database.Mapper.GetToDbConverter(keyValuePair.Value.ColumnType, keyValuePair.Value.PropertyInfo.PropertyType);
                  if (toDbConverter != null)
                    obj = toDbConverter(obj);
                }
                if (keyValuePair.Value.VersionColumn)
                {
                  obj = (object) 1;
                  key = keyValuePair.Key;
                }
                list3.Add(obj);
              }
            }
          }
          IDbCommand cmd = this.CreateCommand(this._sharedConnection, "", new object[0]);
          try
          {
            string str1 = string.Empty;
            string str2 = string.Empty;
            if (autoIncrement)
              str2 = this._dbType.GetInsertOutputClause(primaryKeyName);
            string str3;
            if (list1.Count != 0)
              str3 = string.Format("INSERT INTO {0} ({1}){2} VALUES ({3})", (object) this._dbType.EscapeTableName(tableName), (object) string.Join(",", list1.ToArray()), (object) str2, (object) string.Join(",", list2.ToArray()));
            else
              str3 = this._dbType.GetDefaultInsertSql(tableName, list1.ToArray(), list2.ToArray());
            cmd.CommandText = str3;
            list3.ForEach((Action<object>) (x => this.AddParam(cmd, x, this._paramPrefix)));
            if (!autoIncrement)
            {
              this.DoPreExecute(cmd);
              cmd.ExecuteNonQuery();
              this.OnExecutedCommand(cmd);
              PocoColumn pocoColumn;
              if (primaryKeyName != null && pocoData.Columns.TryGetValue(primaryKeyName, out pocoColumn))
                return pocoColumn.GetValue(poco);
              else
                return (object) null;
            }
            else
            {
              object val = this._dbType.ExecuteInsert(this, cmd, primaryKeyName);
              PocoColumn pocoColumn1;
              if (primaryKeyName != null && pocoData.Columns.TryGetValue(primaryKeyName, out pocoColumn1))
                pocoColumn1.SetValue(poco, pocoColumn1.ChangeType(val));
              PocoColumn pocoColumn2;
              if (!string.IsNullOrEmpty(key) && pocoData.Columns.TryGetValue(key, out pocoColumn2))
                pocoColumn2.SetValue(poco, pocoColumn2.ChangeType((object) 1));
              return val;
            }
          }
          finally
          {
            if (cmd != null)
              cmd.Dispose();
          }
        }
        finally
        {
          this.CloseSharedConnection();
        }
      }
      catch (Exception ex)
      {
        this.OnException(ex);
        throw;
      }
    }

    public object Insert(object poco)
    {
      PocoData pocoData = PocoData.ForType(poco.GetType());
      return this.Insert(pocoData.TableInfo.TableName, pocoData.TableInfo.PrimaryKey, pocoData.TableInfo.AutoIncrement, poco);
    }

    public int Update(string tableName, string primaryKeyName, object poco, object primaryKeyValue)
    {
      return this.Update(tableName, primaryKeyName, poco, primaryKeyValue, (IEnumerable<string>) null);
    }

    public int Update(string tableName, string primaryKeyName, object poco, object primaryKeyValue, IEnumerable<string> columns)
    {
      if (columns != null && !Enumerable.Any<string>(columns))
        return 0;
      StringBuilder stringBuilder = new StringBuilder();
      int index = 0;
      List<object> list = new List<object>();
      PocoData pocoData = PocoData.ForObject(poco, primaryKeyName);
      string str = (string) null;
      object obj1 = (object) null;
      Dictionary<string, object> primaryKeyValues = this.GetPrimaryKeyValues(primaryKeyName, primaryKeyValue);
      foreach (KeyValuePair<string, PocoColumn> keyValuePair in pocoData.Columns)
      {
        if (primaryKeyValue == null && primaryKeyValues.ContainsKey(keyValuePair.Key))
          primaryKeyValues[keyValuePair.Key] = keyValuePair.Value.GetValue(poco);
        else if (!keyValuePair.Value.ResultColumn && (keyValuePair.Value.VersionColumn || columns == null || Enumerable.Contains<string>(columns, keyValuePair.Value.ColumnName, (IEqualityComparer<string>) StringComparer.OrdinalIgnoreCase)))
        {
          object obj2 = keyValuePair.Value.GetValue(poco);
          if (Database.Mapper != null)
          {
            Func<object, object> toDbConverter = Database.Mapper.GetToDbConverter(keyValuePair.Value.ColumnType, keyValuePair.Value.PropertyInfo.PropertyType);
            if (toDbConverter != null)
              obj2 = toDbConverter(obj2);
          }
          if (keyValuePair.Value.VersionColumn)
          {
            str = keyValuePair.Key;
            obj1 = obj2;
            obj2 = (object) (Convert.ToInt64(obj2) + 1L);
          }
          if (index > 0)
            stringBuilder.Append(", ");
          stringBuilder.AppendFormat("{0} = @{1}", (object) this._dbType.EscapeSqlIdentifier(keyValuePair.Key), (object) index++);
          list.Add(obj2);
        }
      }
      if (columns != null && Enumerable.Any<string>(columns) && stringBuilder.Length == 0)
        throw new ArgumentException("There were no columns in the columns list that matched your table", "columns");
      string sql = string.Format("UPDATE {0} SET {1} WHERE {2}", (object) this._dbType.EscapeTableName(tableName), (object) stringBuilder, (object) this.BuildPrimaryKeySql(primaryKeyValues, ref index));
      list.AddRange(Enumerable.Select<KeyValuePair<string, object>, object>((IEnumerable<KeyValuePair<string, object>>) primaryKeyValues, (Func<KeyValuePair<string, object>, object>) (keyValue => keyValue.Value)));
      if (!string.IsNullOrEmpty(str))
      {
        sql = sql + string.Format(" AND {0} = @{1}", (object) this._dbType.EscapeSqlIdentifier(str), (object) index++);
        list.Add(obj1);
      }
      int num = this.Execute(sql, list.ToArray());
      if (num == 0 && !string.IsNullOrEmpty(str) && this.VersionException == VersionExceptionHandling.Exception)
        throw new DBConcurrencyException(string.Format("A Concurrency update occurred in table '{0}' for primary key value(s) = '{1}' and version = '{2}'", (object) tableName, (object) string.Join(",", Enumerable.ToArray<string>(Enumerable.Select<object, string>((IEnumerable<object>) primaryKeyValues.Values, (Func<object, string>) (x => x.ToString())))), obj1));
      PocoColumn pocoColumn;
      if (!string.IsNullOrEmpty(str) && pocoData.Columns.TryGetValue(str, out pocoColumn))
        pocoColumn.SetValue(poco, Convert.ChangeType((object) (Convert.ToInt64(obj1) + 1L), pocoColumn.PropertyInfo.PropertyType));
      return num;
    }

    private string BuildPrimaryKeySql(Dictionary<string, object> primaryKeyValuePair, ref int index)
    {
      int tempIndex = index;
      index += primaryKeyValuePair.Count;
      return string.Join(" AND ", Enumerable.ToArray<string>(Enumerable.Select<KeyValuePair<string, object>, string>((IEnumerable<KeyValuePair<string, object>>) primaryKeyValuePair, (Func<KeyValuePair<string, object>, int, string>) ((x, i) => string.Format("{0} = @{1}", (object) this._dbType.EscapeSqlIdentifier(x.Key), (object) (tempIndex + i))))));
    }

    private Dictionary<string, object> GetPrimaryKeyValues(string primaryKeyName, object primaryKeyValue)
    {
      string[] strArray = Enumerable.ToArray<string>(Enumerable.Select<string, string>((IEnumerable<string>) primaryKeyName.Split(new char[1]
      {
        ','
      }, StringSplitOptions.RemoveEmptyEntries), (Func<string, string>) (x => x.Trim())));
      Dictionary<string, object> dictionary;
      if (primaryKeyValue != null)
      {
        if (strArray.Length == 1)
          dictionary = new Dictionary<string, object>((IEqualityComparer<string>) StringComparer.OrdinalIgnoreCase)
          {
            {
              primaryKeyName,
              primaryKeyValue
            }
          };
        else
          dictionary = Enumerable.ToDictionary<string, string, object>((IEnumerable<string>) strArray, (Func<string, string>) (x => x), (Func<string, object>) (x => Enumerable.Single<PropertyInfo>(Enumerable.Where<PropertyInfo>((IEnumerable<PropertyInfo>) primaryKeyValue.GetType().GetProperties(), (Func<PropertyInfo, bool>) (y => string.Equals(x, y.Name, StringComparison.OrdinalIgnoreCase)))).GetValue(primaryKeyValue, (object[]) null)), (IEqualityComparer<string>) StringComparer.OrdinalIgnoreCase);
      }
      else
        dictionary = Enumerable.ToDictionary<string, string, object>((IEnumerable<string>) strArray, (Func<string, string>) (x => x), (Func<string, object>) (x => (object) null), (IEqualityComparer<string>) StringComparer.OrdinalIgnoreCase);
      return dictionary;
    }

    public int Update(string tableName, string primaryKeyName, object poco)
    {
      return this.Update(tableName, primaryKeyName, poco, (IEnumerable<string>) null);
    }

    public int Update(string tableName, string primaryKeyName, object poco, IEnumerable<string> columns)
    {
      return this.Update(tableName, primaryKeyName, poco, (object) null, columns);
    }

    public int Update(object poco, IEnumerable<string> columns)
    {
      return this.Update(poco, (object) null, columns);
    }

    public int Update(object poco)
    {
      return this.Update(poco, (object) null, (IEnumerable<string>) null);
    }

    public int Update(object poco, object primaryKeyValue)
    {
      return this.Update(poco, primaryKeyValue, (IEnumerable<string>) null);
    }

    public int Update(object poco, object primaryKeyValue, IEnumerable<string> columns)
    {
      PocoData pocoData = PocoData.ForType(poco.GetType());
      return this.Update(pocoData.TableInfo.TableName, pocoData.TableInfo.PrimaryKey, poco, primaryKeyValue, columns);
    }

    public int Update<T>(string sql, params object[] args)
    {
      return this.Execute(string.Format("UPDATE {0} {1}", (object) this._dbType.EscapeTableName(PocoData.ForType(typeof (T)).TableInfo.TableName), (object) sql), args);
    }

    public int Update<T>(Sql sql)
    {
      return this.Execute(new Sql(string.Format("UPDATE {0}", (object) this._dbType.EscapeTableName(PocoData.ForType(typeof (T)).TableInfo.TableName)), new object[0]).Append(sql));
    }

    public int Delete(string tableName, string primaryKeyName, object poco)
    {
      return this.Delete(tableName, primaryKeyName, poco, (object) null);
    }

    public int Delete(string tableName, string primaryKeyName, object poco, object primaryKeyValue)
    {
      Dictionary<string, object> primaryKeyValues = this.GetPrimaryKeyValues(primaryKeyName, primaryKeyValue);
      if (primaryKeyValue == null)
      {
        foreach (KeyValuePair<string, PocoColumn> keyValuePair in PocoData.ForObject(poco, primaryKeyName).Columns)
        {
          if (primaryKeyValues.ContainsKey(keyValuePair.Key))
            primaryKeyValues[keyValuePair.Key] = keyValuePair.Value.GetValue(poco);
        }
      }
      int index = 0;
      return this.Execute(string.Format("DELETE FROM {0} WHERE {1}", (object) this._dbType.EscapeTableName(tableName), (object) this.BuildPrimaryKeySql(primaryKeyValues, ref index)), Enumerable.ToArray<object>(Enumerable.Select<KeyValuePair<string, object>, object>((IEnumerable<KeyValuePair<string, object>>) primaryKeyValues, (Func<KeyValuePair<string, object>, object>) (x => x.Value))));
    }

    public int Delete(object poco)
    {
      PocoData pocoData = PocoData.ForType(poco.GetType());
      return this.Delete(pocoData.TableInfo.TableName, pocoData.TableInfo.PrimaryKey, poco);
    }

    public int Delete<T>(object pocoOrPrimaryKey)
    {
      if (pocoOrPrimaryKey.GetType() == typeof (T))
        return this.Delete(pocoOrPrimaryKey);
      PocoData pocoData = PocoData.ForType(typeof (T));
      return this.Delete(pocoData.TableInfo.TableName, pocoData.TableInfo.PrimaryKey, (object) null, pocoOrPrimaryKey);
    }

    public int Delete<T>(string sql, params object[] args)
    {
      return this.Execute(string.Format("DELETE FROM {0} {1}", (object) this._dbType.EscapeTableName(PocoData.ForType(typeof (T)).TableInfo.TableName), (object) sql), args);
    }

    public int Delete<T>(Sql sql)
    {
      return this.Execute(new Sql(string.Format("DELETE FROM {0}", (object) this._dbType.EscapeTableName(PocoData.ForType(typeof (T)).TableInfo.TableName)), new object[0]).Append(sql));
    }

    public bool IsNew(string primaryKeyName, object poco)
    {
      PocoColumn pocoColumn;
      object obj;
      if (PocoData.ForObject(poco, primaryKeyName).Columns.TryGetValue(primaryKeyName, out pocoColumn))
      {
        obj = pocoColumn.GetValue(poco);
      }
      else
      {
        if (poco.GetType() == typeof (ExpandoObject))
          return true;
        PropertyInfo property = poco.GetType().GetProperty(primaryKeyName);
        if (property == (PropertyInfo) null)
          throw new ArgumentException(string.Format("The object doesn't have a property matching the primary key column name '{0}'", (object) primaryKeyName));
        obj = property.GetValue(poco, (object[]) null);
      }
      if (obj == null)
        return true;
      Type type = obj.GetType();
      if (!type.IsValueType)
        return obj == null;
      if (type == typeof (long))
        return (long) obj == 0L;
      if (type == typeof (ulong))
        return (long) (ulong) obj == 0L;
      if (type == typeof (int))
        return (int) obj == 0;
      if (type == typeof (uint))
        return (int) (uint) obj == 0;
      if (type == typeof (Guid))
        return (Guid) obj == new Guid();
      else
        return obj == Activator.CreateInstance(obj.GetType());
    }

    public bool IsNew(object poco)
    {
      PocoData pocoData = PocoData.ForType(poco.GetType());
      if (!pocoData.TableInfo.AutoIncrement)
        throw new InvalidOperationException("IsNew() and Save() are only supported on tables with auto-increment/identity primary key columns");
      else
        return this.IsNew(pocoData.TableInfo.PrimaryKey, poco);
    }

    public void Save(string tableName, string primaryKeyName, object poco)
    {
      if (this.IsNew(primaryKeyName, poco))
        this.Insert(tableName, primaryKeyName, true, poco);
      else
        this.Update(tableName, primaryKeyName, poco);
    }

    public void Save(object poco)
    {
      PocoData pocoData = PocoData.ForType(poco.GetType());
      this.Save(pocoData.TableInfo.TableName, pocoData.TableInfo.PrimaryKey, poco);
    }

    private void DoPreExecute(IDbCommand cmd)
    {
      if (this.OneTimeCommandTimeout != 0)
      {
        cmd.CommandTimeout = this.OneTimeCommandTimeout;
        this.OneTimeCommandTimeout = 0;
      }
      else if (this.CommandTimeout != 0)
        cmd.CommandTimeout = this.CommandTimeout;
      this.OnExecutingCommand(cmd);
      this._lastSql = cmd.CommandText;
      this._lastArgs = Enumerable.ToArray<object>(Enumerable.Select<IDataParameter, object>(Enumerable.Cast<IDataParameter>((IEnumerable) cmd.Parameters), (Func<IDataParameter, object>) (parameter => parameter.Value)));
    }

    public string FormatCommand(IDbCommand cmd)
    {
      return this.FormatCommand(cmd.CommandText, Enumerable.ToArray<object>(Enumerable.Select<IDataParameter, object>(Enumerable.Cast<IDataParameter>((IEnumerable) cmd.Parameters), (Func<IDataParameter, object>) (parameter => parameter.Value))));
    }

    public string FormatCommand(string sql, object[] args)
    {
      StringBuilder stringBuilder = new StringBuilder();
      if (sql == null)
        return "";
      stringBuilder.Append(sql);
      if (args != null && args.Length > 0)
      {
        stringBuilder.Append("\n");
        for (int index = 0; index < args.Length; ++index)
          stringBuilder.AppendFormat("\t -> {0}{1} [{2}] = \"{3}\"\n", (object) this._paramPrefix, (object) index, (object) args[index].GetType().Name, args[index]);
        stringBuilder.Remove(stringBuilder.Length - 1, 1);
      }
      return ((object) stringBuilder).ToString();
    }

    internal void ExecuteNonQueryHelper(IDbCommand cmd)
    {
      this.DoPreExecute(cmd);
      cmd.ExecuteNonQuery();
      this.OnExecutedCommand(cmd);
    }

    internal object ExecuteScalarHelper(IDbCommand cmd)
    {
      this.DoPreExecute(cmd);
      object obj = cmd.ExecuteScalar();
      this.OnExecutedCommand(cmd);
      return obj;
    }

    public class DontMap
    {
    }
  }
}
