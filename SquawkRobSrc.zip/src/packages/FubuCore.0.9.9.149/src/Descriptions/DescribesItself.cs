namespace FubuCore.Descriptions
{
    public interface DescribesItself
    {
        void Describe(Description description);
    }
}