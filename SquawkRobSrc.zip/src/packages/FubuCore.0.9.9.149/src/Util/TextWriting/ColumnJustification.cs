namespace FubuCore.Util.TextWriting
{
    public enum ColumnJustification
    {
        left,
        right
    }
}