﻿using System;

namespace FubuCore.CommandLine
{
    [AttributeUsage(AttributeTargets.Property)]
    public class IgnoreOnCommandLineAttribute : Attribute
    {
        
    }
}