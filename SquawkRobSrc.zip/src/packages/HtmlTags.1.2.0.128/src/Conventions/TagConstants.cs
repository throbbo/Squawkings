namespace HtmlTags.Conventions
{
    public static class TagConstants
    {
        public static readonly string Default = "Default";
    }
}